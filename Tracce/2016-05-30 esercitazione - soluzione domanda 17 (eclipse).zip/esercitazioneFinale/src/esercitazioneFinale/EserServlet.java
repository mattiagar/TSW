package esercitazioneFinale;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class eserServlet
 */
@WebServlet("/EserServlet")
public class EserServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();

		if (session.getAttribute("bean") == null) { // primo accesso
			EsBean newBean = new EsBean();
			newBean.setNome("pippo");
			newBean.setCognome("pluto");
			session.setAttribute("bean", newBean);
		} else { // accesso successivo
			EsBean sessionBean = (EsBean) session.getAttribute("bean");
			sessionBean.setNome(request.getParameter("nome"));
			sessionBean.setCognome(request.getParameter("cognome"));
		}

		RequestDispatcher dispatcher = request.getRequestDispatcher("/mvcjsp.jsp");
		dispatcher.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
